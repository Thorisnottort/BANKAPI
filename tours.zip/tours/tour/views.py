from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect, get_object_or_404
from .models import Tour, Roadmap, Order


def is_admin(user):
    return user.is_authenticated and user.is_staff


def index(request):
    return render(request, 'main.html', {'tours': Tour.objects.all()[:3]})


def tour(request, tour_id):
    if request.method == 'POST':
        try:
            user = request.user
        except:
            return redirect('login')
        order_object = Order()
        order_object.tour = Tour.objects.get(id=tour_id)
        order_object.user = user
        order_object.order_name = request.POST.get('name')
        order_object.order_phone = request.POST.get('phone')
        order_object.order_option = request.POST.get('option')
        order_object.save()
        return redirect('profile')
    else:
        tour_object = Tour.objects.get(id=tour_id)
        roadmaps = Roadmap.objects.filter(tour=tour_id)
    return render(request, 'tour.html', {'tour': tour_object, 'roadmaps': roadmaps})


def tours(request):
    max_price = request.GET.get('price')
    max_duration = request.GET.get('duration')
    date_from = request.GET.get('date')

    tours = Tour.objects.all()

    if max_price:
        tours = tours.filter(tour_price__lte=max_price)
    if max_duration:
        tours = tours.filter(tour_duration__lte=max_duration)
    if date_from:
        tours = tours.filter(next_date__gte=date_from)

    return render(request, 'tours.html', {'tours': tours})


@user_passes_test(is_admin, login_url='login')
def admin(request):
    if request.method == 'POST':
        order_id = request.POST.get('order_id')
        status = request.POST.get('status')
        order_object = Order.objects.get(id=order_id)
        order_object.order_successful = True if status == 'paid' else False
        order_object.save()
    return render(request, 'admin.html', {'orders': Order.objects.all()})


def about(request):
    return render(request, 'about.html')


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password, email=email)
            login(request, user)
            return redirect('index')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})


@login_required
def profile(request):
    user_orders = Order.objects.filter(user=request.user)
    return render(request, 'profile.html', {'user': request.user, 'orders': user_orders})


def roadmap_detail(request, pk):
    roadmap = get_object_or_404(Roadmap, pk=pk)
    return render(request, 'roadmap.html', {'roadmap': roadmap})
